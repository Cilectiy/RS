# -*- coding: utf-8 -*-

from __future__ import print_function, division, absolute_import

import logging.handlers


logger = logging.getLogger('pigar')
logger.setLevel(logging.WARNING)
