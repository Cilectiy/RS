from .dicts import Logs

__all__ = ["Logs"]
